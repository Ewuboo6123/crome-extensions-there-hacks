var settings = {
    map_id: null,
    map_seq: null,
    map_ind: null,
    cup_id: null,
    musicEnabled: null,
    autoRestart: null,
    frameRate: null,
    platformTexture: null,
    fovLevel: null,
    screenRes: null
};